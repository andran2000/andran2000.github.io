﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_frame_animation_1 = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_wind_direction_image_progress_img_level = ''
        let idle_wind_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_image_img = ''
        let normal_cal_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: AvantGarde.ttf; FontSize: 21; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 25,
              h: 25,
              text_size: 21,
              char_space: 1,
              line_space: 0,
              font: 'fonts/AvantGarde.ttf',
              color: 0xFFB35402,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 341,
              y: 139,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 322,
              month_startY: 116,
              month_sc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_tc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_en_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 305,
              day_startY: 80,
              day_sc_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_tc_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_en_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 179,
              src: 'aod_bt_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 179,
              src: 'aod_bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 317,
              y: 170,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "dg",
              anim_fps: 15,
              anim_size: 18,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 142,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 108,
              font_array: ["activ_00.png","activ_01.png","activ_02.png","activ_03.png","activ_04.png","activ_05.png","activ_06.png","activ_07.png","activ_08.png","activ_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 47,
              y: 178,
              w: 114,
              h: 29,
              text_size: 21,
              char_space: 1,
              font: 'fonts/AvantGarde.ttf',
              color: 0xFFB35402,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 100,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 108,
              font_array: ["activ_00.png","activ_01.png","activ_02.png","activ_03.png","activ_04.png","activ_05.png","activ_06.png","activ_07.png","activ_08.png","activ_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'activ_12.png',
              unit_tc: 'activ_12.png',
              unit_en: 'activ_12.png',
              negative_image: 'activ_11.png',
              invalid_image: 'activ_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 352,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 359,
              src: 'ic_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 319,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 326,
              src: 'ic_healt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 344,
              font_array: ["activ_00.png","activ_01.png","activ_02.png","activ_03.png","activ_04.png","activ_05.png","activ_06.png","activ_07.png","activ_08.png","activ_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'activ_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 349,
              y: 351,
              src: 'ic_km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 311,
              font_array: ["activ_00.png","activ_01.png","activ_02.png","activ_03.png","activ_04.png","activ_05.png","activ_06.png","activ_07.png","activ_08.png","activ_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 318,
              src: 'ic_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 337,
              y: 189,
              image_array: ["btr_01.png","btr_02.png","btr_03.png","btr_04.png","btr_05.png","btr_06.png","btr_07.png","btr_08.png","btr_09.png","btr_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 221,
              font_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'bat_10.png',
              unit_tc: 'bat_10.png',
              unit_en: 'bat_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 210,
              hour_array: ["time_h_00.png","time_h_01.png","time_h_02.png","time_h_03.png","time_h_04.png","time_h_05.png","time_h_06.png","time_h_07.png","time_h_08.png","time_h_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: 'time_h_10.png',
              hour_unit_tc: 'time_h_10.png',
              hour_unit_en: 'time_h_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 157,
              minute_startY: 210,
              minute_array: ["time_m_00.png","time_m_01.png","time_m_02.png","time_m_03.png","time_m_04.png","time_m_05.png","time_m_06.png","time_m_07.png","time_m_08.png","time_m_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'time_h_10.png',
              minute_unit_tc: 'time_h_10.png',
              minute_unit_en: 'time_h_10.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 250,
              second_startY: 210,
              second_array: ["time_s_00.png","time_s_01.png","time_s_02.png","time_s_03.png","time_s_04.png","time_s_05.png","time_s_06.png","time_s_07.png","time_s_08.png","time_s_09.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 405,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'alarm1.png',
              dot_image: 'activ_w_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 341,
              y: 139,
              week_en: ["aod_week_1.png","aod_week_2.png","aod_week_3.png","aod_week_4.png","aod_week_5.png","aod_week_6.png","aod_week_7.png"],
              week_tc: ["aod_week_1.png","aod_week_2.png","aod_week_3.png","aod_week_4.png","aod_week_5.png","aod_week_6.png","aod_week_7.png"],
              week_sc: ["aod_week_1.png","aod_week_2.png","aod_week_3.png","aod_week_4.png","aod_week_5.png","aod_week_6.png","aod_week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 322,
              month_startY: 116,
              month_sc_array: ["aod_mon_1.png","aod_mon_2.png","aod_mon_3.png","aod_mon_4.png","aod_mon_5.png","aod_mon_6.png","aod_mon_7.png","aod_mon_8.png","aod_mon_9.png","aod_mon_10.png","aod_mon_11.png","aod_mon_12.png"],
              month_tc_array: ["aod_mon_1.png","aod_mon_2.png","aod_mon_3.png","aod_mon_4.png","aod_mon_5.png","aod_mon_6.png","aod_mon_7.png","aod_mon_8.png","aod_mon_9.png","aod_mon_10.png","aod_mon_11.png","aod_mon_12.png"],
              month_en_array: ["aod_mon_1.png","aod_mon_2.png","aod_mon_3.png","aod_mon_4.png","aod_mon_5.png","aod_mon_6.png","aod_mon_7.png","aod_mon_8.png","aod_mon_9.png","aod_mon_10.png","aod_mon_11.png","aod_mon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 305,
              day_startY: 80,
              day_sc_array: ["aod_data_00.png","aod_data_01.png","aod_data_02.png","aod_data_03.png","aod_data_04.png","aod_data_05.png","aod_data_06.png","aod_data_07.png","aod_data_08.png","aod_data_09.png"],
              day_tc_array: ["aod_data_00.png","aod_data_01.png","aod_data_02.png","aod_data_03.png","aod_data_04.png","aod_data_05.png","aod_data_06.png","aod_data_07.png","aod_data_08.png","aod_data_09.png"],
              day_en_array: ["aod_data_00.png","aod_data_01.png","aod_data_02.png","aod_data_03.png","aod_data_04.png","aod_data_05.png","aod_data_06.png","aod_data_07.png","aod_data_08.png","aod_data_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 179,
              src: 'aod_bt_on.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 179,
              src: 'aod_bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 142,
              image_array: ["aod_wind_1.png","aod_wind_2.png","aod_wind_3.png","aod_wind_4.png","aod_wind_5.png","aod_wind_6.png","aod_wind_7.png","aod_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 108,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 100,
              image_array: ["aod_weatherd_00.png","aod_weatherd_01.png","aod_weatherd_02.png","aod_weatherd_03.png","aod_weatherd_04.png","aod_weatherd_05.png","aod_weatherd_06.png","aod_weatherd_07.png","aod_weatherd_08.png","aod_weatherd_09.png","aod_weatherd_10.png","aod_weatherd_11.png","aod_weatherd_12.png","aod_weatherd_13.png","aod_weatherd_14.png","aod_weatherd_15.png","aod_weatherd_16.png","aod_weatherd_17.png","aod_weatherd_18.png","aod_weatherd_19.png","aod_weatherd_20.png","aod_weatherd_21.png","aod_weatherd_22.png","aod_weatherd_23.png","aod_weatherd_24.png","aod_weatherd_25.png","aod_weatherd_26.png","aod_weatherd_27.png","aod_weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 108,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'activ_w_13.png',
              unit_tc: 'activ_w_13.png',
              unit_en: 'activ_w_13.png',
              negative_image: 'activ_w_12.png',
              invalid_image: 'activ_w_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 352,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 359,
              src: 'ic_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 319,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 326,
              src: 'ic_healt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 344,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'activ_w_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 349,
              y: 351,
              src: 'ic_km_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 311,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 318,
              src: 'ic_steps_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 337,
              y: 189,
              image_array: ["aod_btr_01_aod.png","aod_btr_02_aod.png","aod_btr_03_aod.png","aod_btr_04_aod.png","aod_btr_05_aod.png","aod_btr_06_aod.png","aod_btr_07_aod.png","aod_btr_08_aod.png","aod_btr_09_aod.png","aod_btr_10_aod.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 221,
              font_array: ["aod_bat_00.png","aod_bat_01.png","aod_bat_02.png","aod_bat_03.png","aod_bat_04.png","aod_bat_05.png","aod_bat_06.png","aod_bat_07.png","aod_bat_08.png","aod_bat_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'aod_bat_10.png',
              unit_tc: 'aod_bat_10.png',
              unit_en: 'aod_bat_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 210,
              hour_array: ["aod_time_h_00.png","aod_time_h_01.png","aod_time_h_02.png","aod_time_h_03.png","aod_time_h_04.png","aod_time_h_05.png","aod_time_h_06.png","aod_time_h_07.png","aod_time_h_08.png","aod_time_h_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: 'aod_time_h_10.png',
              hour_unit_tc: 'aod_time_h_10.png',
              hour_unit_en: 'aod_time_h_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 157,
              minute_startY: 210,
              minute_array: ["aod_time_m_00.png","aod_time_m_01.png","aod_time_m_02.png","aod_time_m_03.png","aod_time_m_04.png","aod_time_m_05.png","aod_time_m_06.png","aod_time_m_07.png","aod_time_m_08.png","aod_time_m_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'time_h_10.png',
              minute_unit_tc: 'time_h_10.png',
              minute_unit_en: 'time_h_10.png',
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top2_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 405,
              font_array: ["activ_w_00.png","activ_w_01.png","activ_w_02.png","activ_w_03.png","activ_w_04.png","activ_w_05.png","activ_w_06.png","activ_w_07.png","activ_w_08.png","activ_w_09.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'alarm1.png',
              dot_image: 'activ_w_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 350,
              w: 117,
              h: 44,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 87,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 87,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 223,
              y: 87,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 305,
              y: 78,
              w: 87,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 49,
              y: 202,
              w: 87,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 196,
              w: 87,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 242,
              y: 196,
              w: 87,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 196,
              w: 87,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 122,
              y: 291,
              w: 117,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 272,
              y: 283,
              w: 117,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 272,
              y: 342,
              w: 117,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 394,
              w: 97,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 15,
              w: 97,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}